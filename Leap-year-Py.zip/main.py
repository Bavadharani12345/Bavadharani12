year=int(input("enter a year:"))
if(year %4==0):
  print("The given year is leapyear")
else:
  print("The given year is not a leap year")